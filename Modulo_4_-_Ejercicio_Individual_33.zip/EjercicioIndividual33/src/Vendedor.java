public class Vendedor extends Empleado {

    private String fechaInicio;


    public Vendedor(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Vendedor(String nombre, String apellido, int edad, int salario, String fechaInicio) {
        super(nombre, apellido, edad, salario);
        this.fechaInicio = fechaInicio;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public int calcularSalario() {
        int bono = 50000;
        if (super.getEdad() > 40){

            bono += 100000;
        }
        return super.getSalario() + bono;
    }


    @Override
    public String toString() {
        return "Vendedor{" +
                "fechaInicio='" + fechaInicio + '\'' +
                '}';
    }
}
