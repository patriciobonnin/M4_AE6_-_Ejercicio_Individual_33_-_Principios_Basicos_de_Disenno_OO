public class Repartidor extends Empleado {

    private String disponibilidadHoraria;

    public Repartidor(String disponibilidadHoraria) {
        this.disponibilidadHoraria = disponibilidadHoraria;
    }

    public Repartidor(String nombre, String apellido, int edad, int salario, String disponibilidadHoraria) {
        super(nombre, apellido, edad, salario);
        this.disponibilidadHoraria = disponibilidadHoraria;

    }

    public String getDisponibilidadHoraria() {
        return disponibilidadHoraria;
    }

    public void setDisponibilidadHoraria(String disponibilidadHoraria) {
        this.disponibilidadHoraria = disponibilidadHoraria;
    }

    @Override
    public int calcularSalario() {
        int bono = 0;
        if (super.getEdad() < 30) {
            bono += 15000;
        }
        return super.getSalario() + bono;
    }

    @Override
    public String toString() {
        return "Repartidor{" +
                "disponibilidadHoraria='" + disponibilidadHoraria + '\'' +
                '}';
    }
}