public class Main {

    public static void main(String[] args) {


            Empleado[] empleados = new Empleado[10];
            empleados[0] = new Vendedor("Juan", "Pérez", 35, 1000000, "01/01/2020");
            empleados[1] = new Repartidor("María", "García", 28, 800000, "Mañana");
            empleados[2] = new Vendedor("Pedro", "González", 42, 1200000, "01/06/2019");
            empleados[3] = new Repartidor("Ana", "Rodríguez", 30, 900000, "Tarde");
            empleados[4] = new Vendedor("José", "Hernández", 45, 1100000, "01/03/2018");
            empleados[5] = new Repartidor("Carmen", "Martínez", 32, 850000, "Noche");
            empleados[6] = new Vendedor("Francisco", "López", 50, 1300000, "01/09/2017");
            empleados[7] = new Repartidor("Marta", "Sánchez", 25, 950000, "Mañana");
            empleados[8] = new Vendedor("Javier", "Pérez", 55, 1400000, "01/12/2016");
            empleados[9] = new Repartidor("Laura", "Gómez", 29, 1000000, "Tarde");

            for (Empleado empleado : empleados) {
                System.out.println(empleado);
                System.out.println("Nombre: "+empleado.getNombre() +" Salario: "+ empleado.calcularSalario());
                System.out.println();
            }



    }
}